from django.conf import settings
from django.db import models
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import ugettext_lazy as _





class User(models.Model):
    class Location_Name(models.TextChoices):
        Newbury='Newbury'
        London='London'
        Reading='Reading'
    class Condition(models.TextChoices):
        Increase='Increase'
        Decrease='Decrease'
    user_id = models.AutoField(primary_key=True)
    name_surname=models.CharField(max_length=100,default="Name")
    email = models.EmailField(max_length=100,unique=True)
    location_name=models.CharField(
        max_length=20,choices=Location_Name.choices,
        default=Location_Name.London
    )
    temp=models.IntegerField()
    condition=models.CharField(max_length=20,choices=Condition.choices,default=Condition.Increase)
    created_date = models.DateTimeField(
        default=timezone.now)


    def __str__(self):
        return self.email,self.temp,self.condition
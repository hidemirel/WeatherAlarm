from django.shortcuts import render
from django.utils import timezone
from .models import User
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions
from rest_framework import request
from .models import User
from .serializers import UserSerializer
from rest_framework.generics import get_object_or_404
from django.core.validators import validate_email
import requests
from rest_framework_swagger.views import get_swagger_view
from django.conf.urls import url

schema_view = get_swagger_view(title='OpenWeather  API')

urlpatterns = [
    url(r'^$', schema_view)
]
def post_user(request):
    posts = User.objects.all()
    return render(request, 'weatherapi/post_user.html', {'posts': posts})

# Create yours here.

class UserListApiView(APIView):
    # add permission to check if user is authenticated
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        '''
        List all the todo items for given requested user
        '''
        Users= User.objects.all()
        serializer = UserSerializer(Users, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        '''
        Create the Todo with given todo data
        '''
        data = {
            'name_surname': request.data.get('name_surname'),
            'email': request.data.get('email'),
            'location_name': request.data.get('location_name'),
            'temp':request.data.get('temp'),
            'condition':request.data.get('condition')

        }

        serializer = UserSerializer(data=data)
        if serializer.is_valid() :
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserDetailApiView(APIView):
    # add permission to check if user is authenticated
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self, user_id):
        user_instance=get_object_or_404(User,user_id=user_id)
        return user_instance
    # 3. Retrieve
    def get(self, request, user_id, *args, **kwargs):

        user_instance = self.get_object(user_id)
        if not user_instance:
            return Response(
                {"res": "Object with User id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = UserSerializer(user_instance)
        return Response(serializer.data, status=status.HTTP_200_OK)

    # 4. Update
    def put(self, request, user_id, *args, **kwargs):
        '''
        Updates the todo item with given todo_id if exists
        '''
        user_instance = self.get_object(user_id)
        if not user_instance:
            return Response(
                {"res": "Object with todo id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        data = data = {
            'name_surname': request.data.get('name_surname'),
            'email': request.data.get('email'),
            'location_name': request.data.get('location_name'),
            'temp':request.data.get('temp'),
            'condition':request.data.get('condition')

        }
        serializer = UserSerializer(instance = user_instance, data=data, partial = True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # 5. Delete
    def delete(self, request, user_id, *args, **kwargs):
        '''
        Deletes the todo item with given todo_id if exists
        '''
        user_instance = self.get_object(user_id)
        if not user_instance:
            return Response(
                {"res": "Object with todo id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        user_instance.delete()
        return Response(
            {f"Object deleted! user_id={user_id} "},
            status=status.HTTP_200_OK
        )


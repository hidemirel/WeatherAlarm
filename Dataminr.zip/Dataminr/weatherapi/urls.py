from django.urls import path
from .  import views
from .views import (
UserListApiView,UserDetailApiView,post_user
)
urlpatterns = [
   # path('', views.post_user, name='post_user'),
    path('',UserListApiView.as_view(),name='all_list'),
    path('<int:user_id>/',UserDetailApiView.as_view(),name='detail'),


]
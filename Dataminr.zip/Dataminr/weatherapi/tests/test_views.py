from django.urls import reverse,resolve
from django.test import SimpleTestCase
from weatherapi.views import UserListApiView,UserDetailApiView
from rest_framework.test import APITestCase
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from rest_framework import status

class CustomerAPIViewTest(APITestCase):
    client_url=reverse('all_list')
    def SetUP(self):
        self.user=User.objects.create_user(username='admin',password='strong-pass')
        self.token=Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION='Token' + self.token.key)

    def tearDown(self):
        pass

    def test_get_client_authenticated(self):
        response=self.client.get(self.client_url)
        self.assertEqual(response.status_code,status.HTTP_200_OK)

    def test_post_client_authenticated(self):
        data={
            "user"




        }
from django.test import SimpleTestCase
from django.urls import reverse,resolve
from weatherapi.views import UserListApiView

class TestApiUrls(SimpleTestCase):
    def test_get_all_list(self):
        url=reverse('all_list')
        print(resolve(url).func)
        self.assertEquals(resolve(url).func.view_class,UserListApiView)



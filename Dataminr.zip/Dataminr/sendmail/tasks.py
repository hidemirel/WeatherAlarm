from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
import requests
from weatherapi.models import User
from weatherapi.serializers import UserSerializer
from .monitor import Monitor

city_list=Monitor().city()
city_temp=Monitor().monitor_weather(city_list)
@shared_task
def send_mail_task():
    print("Mail sending.......")
    Users = User.objects.all()
    serializer = UserSerializer(Users, many=True)
    subject = 'Welcome to Openweather Alarm '

    email_from = settings.EMAIL_HOST_MAIL
   # recipient_list_active = list(User.objects.values_list('email', flat=True))
    #recipient_list = ['halil.demirel@turkcell.com.tr',

    for i in serializer.data:
        #print("Serialize data",i['condition'],i['temp'],i['location_name'])
        #print(city_temp[i['location_name']])
        condition = i['condition']
        print(i['email'])
        print(condition)
        print(i['temp'])
        print(city_temp)
        mail_list=[]
        if condition == 'Increase' and i['temp'] < city_temp[i['location_name']]:
            try:
                message = f"Hi thank you for Openweather Alarm location {i['location_name']} temperature is increase !!! Temp condition: {i['temp']} Today Temperature: {city_temp[i['location_name']]}"
                mail_list.append(i['email'])
                send_mail(subject, message, email_from, mail_list)

            except Exception as error:

                return f"Mail gonderilemedi {error}"

        elif condition == 'Decrease' and i['temp'] > city_temp[i['location_name']]:
            try:
                message = f"Hi thank you for Openweather Alarm location {i['location_name']} temperature is decrease !!! Temp condition: {i['temp']} Today Temperature: {city_temp[i['location_name']]}"

                send_mail(subject, message, email_from, i['email'])
                mail_list.append(i['email'])
            except Exception as error:
                print(f"Mail gonderilemedi {error}")
                return f"Mail gonderilemedi {error}"

        else:
            return f"Users didn't any match condition"

    return f"Mail has been sent {mail_list}."



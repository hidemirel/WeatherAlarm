import requests
from weatherapi.models import User
from weatherapi.serializers import UserSerializer

class Monitor():

    def city(self):
        Users = User.objects.all()
        serializer = UserSerializer(Users, many=True)
        city_name=[]
        city_unique=set()
        for i in serializer.data:
            city_name.append(i['location_name'])
        city_unique.update(city_name)
        return city_unique

    def monitor_weather(self,city_list):

        city_temp = {}
        api_key='f58456b71ade7ea95a683dbc14936e4a'
        for city_ in city_list:
            req = f"https://api.openweathermap.org/data/2.5/weather?q={city_}&appid={api_key}&units=metric"
            try:
                result = requests.get(req,verify=False)
                if result.status_code == 200:
                    city_temp[city_] = result.json()['main']['temp']

                else:
                    return f"Cannot  fetch data from Openweather API"
            except Exception as error:
                return f"Please check internet connection error : {error}"
        return city_temp


